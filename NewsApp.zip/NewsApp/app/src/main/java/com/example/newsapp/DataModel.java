package com.example.newsapp;

public class DataModel {
    private String image;
    private String title;
    private String content;
    private String author;

    private String date;

    public DataModel(String title, String content, String image, String author, String date){

        this.title=title;
        this.content=content;
        this.image=image;
        this.author=author;
        this.date=date;
    }


    public String getTitle() {return title;}

    public String getContent() {return content;}
    public String getImage() {return image;}


    public String getAuthor() {return author;}

    public String getDate() {return date;}
}
