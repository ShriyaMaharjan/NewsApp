package com.example.newsapp;

import static android.content.ContentValues.TAG;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.snackbar.Snackbar;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recycler_view);

        RecyclerView recyclerView = findViewById(R.id.recyclerView);

        ArrayList<DataModel> tasks = new ArrayList<DataModel>();

        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);

        RecyclerViewAdapter adapter = new RecyclerViewAdapter(this, tasks);
        recyclerView.setAdapter(adapter);



        String apiUrl = "https://inshorts.deta.dev/news?category=all";

        RequestQueue requestQueue = Volley.newRequestQueue(this);

        StringRequest stringRequest = new StringRequest(
                Request.Method.GET,
                apiUrl,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        String jsonData = response;
                        Log.d("JSON DATA:", jsonData);

                        jsonArrayDecode(jsonData, adapter);
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.d("error",error.toString());
                View view = findViewById(R.id.recyclerView);
                Snackbar.make(view,"Please check your internet connection",Snackbar.LENGTH_LONG).show();

            }
        }
        );
        requestQueue.add(stringRequest);

        EditText categoryTv = findViewById(R.id.categoryTv);


        categoryTv.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if ((event != null && (event.getKeyCode() == KeyEvent.KEYCODE_ENTER)) || (actionId == EditorInfo.IME_ACTION_DONE)) {
                    Log.i(TAG, "Enter pressed");
                    String category = categoryTv.getText().toString();
                    String apiUrl = "https://inshorts.deta.dev/news?category=" + category;

                    RequestQueue requestQueue = Volley.newRequestQueue(MainActivity.this);

                    StringRequest stringRequest = new StringRequest(
                            Request.Method.GET,
                            apiUrl,
                            new Response.Listener<String>() {
                                @Override
                                public void onResponse(String response) {
                                    String jsonData = response;
                                    Log.d("JSON DATA:", jsonData);

                                    jsonArrayDecode(jsonData, adapter);
                                }
                            }, new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            Log.d("error", error.toString());
                            View view = findViewById(R.id.recyclerView);
                            Snackbar.make(view, "Please check your internet connection", Snackbar.LENGTH_LONG).show();

                        }
                    }
                    );
                    requestQueue.add(stringRequest);

                }
                return false;
            }
        });
    }

    public void jsonArrayDecode(String jsonData, RecyclerViewAdapter adapter){
        ArrayList<DataModel> data = new ArrayList<>();
        try{
            JSONObject jsonObject = new JSONObject(jsonData);
            JSONArray posts = jsonObject.getJSONArray("data");

            for(int i=0; i<posts.length();i++){
                JSONObject post = posts.getJSONObject(i);

                // String image = post.getString("image");
                String title = post.getString("title");
                String content = post.getString("content");
                String imageUrl = post.getString("imageUrl");
                String author = post.getString("author");
                String date = post.getString("date");
                // String category = post.getString("category");

                data.add(new DataModel(title, content, imageUrl, author, date));

            }
            adapter.setPosts(data);
        }catch (JSONException e) {
            throw new RuntimeException(e);
        }
    }
}

