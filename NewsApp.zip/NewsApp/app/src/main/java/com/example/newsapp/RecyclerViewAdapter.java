package com.example.newsapp;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class RecyclerViewAdapter extends RecyclerView.Adapter<RecyclerViewAdapter.ViewHolder> {

    Activity activity;

    ArrayList<DataModel> posts;

    public RecyclerViewAdapter(Activity activity, ArrayList<DataModel> posts) {
        this.activity = activity;
        this.posts = posts;
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {

        ImageView imageView;
        TextView titleTv, descTv, authorTv, dateTv;
        EditText categoryTv;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            titleTv = itemView.findViewById(R.id.titleTv);

            descTv = itemView.findViewById(R.id.descTv);
            imageView = itemView.findViewById(R.id.imageView);
            authorTv = itemView.findViewById(R.id.authorTv);
            dateTv = itemView.findViewById(R.id.dateTv);

        }
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(activity);
        View listItem = layoutInflater.inflate(R.layout.activity_main, parent, false);
        ViewHolder viewHolder = new ViewHolder(listItem);
        return viewHolder;

    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerViewAdapter.ViewHolder holder, int position) {
        holder.titleTv.setText(posts.get(position).getTitle());
        holder.descTv.setText(posts.get(position).getContent());
        holder.authorTv.setText(posts.get(position).getAuthor());
        holder.dateTv.setText(posts.get(position).getDate());
        // holder.categoryTv.setText(posts.get(position).getCategory());
        String image = posts.get(position).getImage();
        if (image != null && image.length() > 0) {
            Picasso.get().load(posts.get(position).getImage()).into(holder.imageView);
        }
    }

    @Override
    public int getItemCount() {
        return posts.size();
    }

    public void setPosts(ArrayList<DataModel> posts) {
        this.posts = posts;
        notifyDataSetChanged();
    }
}


